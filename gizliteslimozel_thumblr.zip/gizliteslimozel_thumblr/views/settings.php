<div class="p-4 sm:p-6 bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl rounded-3xl border border-gray-200 dark:border-gray-700/50 shadow-xl"
    x-data="{
        newUsername: '',
        currentPasswordForUsername: '',
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
        handleUsernameChange(e) {
            e.preventDefault();
            const formData = new FormData();
            formData.append('action', 'change_username');
            formData.append('new_username', this.newUsername);
            formData.append('current_password', this.currentPasswordForUsername);

            fetch('/includes/api.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: data.message,
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000,
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                        }
                    }).then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: data.message,
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        confirmButtonColor: '#9333ea',
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                            confirmButton: 'rounded-xl'
                        }
                    });
                }
            });
        },
        handlePasswordChange(e) {
            e.preventDefault();
            const formData = new FormData();
            formData.append('action', 'change_password');
            formData.append('current_password', this.currentPassword);
            formData.append('new_password', this.newPassword);
            formData.append('confirm_password', this.confirmPassword);

            fetch('/includes/api.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: data.message,
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000,
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                        }
                    }).then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: data.message,
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        confirmButtonColor: '#9333ea',
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                            confirmButton: 'rounded-xl'
                        }
                    });
                }
            });
        }
    }"
    x-init="$store.app.currentPage = 'settings'">
    <div class="mb-6">
        <h2 class="text-2xl font-secondary font-bold text-gray-800 dark:text-white">Hesap Ayarları</h2>
        <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">Kullanıcı adı ve şifre bilgilerinizi buradan güncelleyebilirsiniz.</p>
    </div>

    <!-- Kullanıcı Adı Değiştirme Formu -->
    <div class="mb-8 p-6 bg-gray-50/50 dark:bg-gray-900/50 rounded-2xl border border-gray-200/50 dark:border-gray-700/50">
        <h3 class="text-lg font-secondary font-semibold text-gray-800 dark:text-white mb-4">Kullanıcı Adı Değiştir</h3>
        <form @submit.prevent="handleUsernameChange" class="space-y-4">
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-user text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="text" 
                    x-model="newUsername"
                    class="block w-full pl-11 pr-4 py-3 text-sm border-2 border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Yeni Kullanıcı Adı"
                    required
                >
            </div>
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-lock text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="password" 
                    x-model="currentPasswordForUsername"
                    class="block w-full pl-11 pr-4 py-3 text-sm border-2 border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Mevcut Şifre"
                    required
                >
            </div>
            <button type="submit" class="w-full flex items-center justify-center px-6 py-3 text-sm font-medium text-white bg-gradient-to-br from-primary-500 via-primary-600 to-primary-500 hover:from-primary-600 hover:via-primary-700 hover:to-primary-600 rounded-xl shadow-lg shadow-primary-500/20 transform hover:-translate-y-0.5 transition-all duration-200">
                <i class="fa-solid fa-user-pen mr-2 text-white/90"></i>
                Kullanıcı Adını Güncelle
            </button>
        </form>
    </div>

    <!-- Şifre Değiştirme Formu -->
    <div class="p-6 bg-gray-50/50 dark:bg-gray-900/50 rounded-2xl border border-gray-200/50 dark:border-gray-700/50">
        <h3 class="text-lg font-secondary font-semibold text-gray-800 dark:text-white mb-4">Şifre Değiştir</h3>
        <form @submit.prevent="handlePasswordChange" class="space-y-4">
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-lock text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="password" 
                    x-model="currentPassword"
                    class="block w-full pl-11 pr-4 py-3 text-sm border-2 border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Mevcut Şifre"
                    required
                >
            </div>
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-key text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="password" 
                    x-model="newPassword"
                    class="block w-full pl-11 pr-4 py-3 text-sm border-2 border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Yeni Şifre"
                    required
                >
            </div>
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-key text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="password" 
                    x-model="confirmPassword"
                    class="block w-full pl-11 pr-4 py-3 text-sm border-2 border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Yeni Şifre (Tekrar)"
                    required
                >
            </div>
            <button type="submit" class="w-full flex items-center justify-center px-6 py-3 text-sm font-medium text-white bg-gradient-to-br from-primary-500 via-primary-600 to-primary-500 hover:from-primary-600 hover:via-primary-700 hover:to-primary-600 rounded-xl shadow-lg shadow-primary-500/20 transform hover:-translate-y-0.5 transition-all duration-200">
                <i class="fa-solid fa-shield-halved mr-2 text-white/90"></i>
                Şifreyi Güncelle
            </button>
        </form>
    </div>
</div> 