<?php
// Link düzenleme sayfası
?>
<div class="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl border border-gray-200 dark:border-gray-700 p-6"
    x-data="{
        linkId: null,
        link_url: '',
        urlredgrim_url: '',
        browserSelections: {
            chrome: false,
            firefox: false,
            safari: false,
            edge: false,
            opera: false
        },
        osSelections: {
            windows: false,
            macos: false,
            linux: false,
            android: false,
            ios: false
        },
        get browsers() {
            return Object.entries(this.browserSelections)
                .filter(([_, selected]) => selected)
                .map(([browser]) => browser);
        },
        get osSystems() {
            return Object.entries(this.osSelections)
                .filter(([_, selected]) => selected)
                .map(([os]) => os);
        },
        mobileOff: false,
        desktopOff: false,
        active: true,
        loading: true,
        js_url: '',
        redirect_delay: 0,
        selectAllBrowsers() {
            const allSelected = Object.values(this.browserSelections).every(v => v);
            Object.keys(this.browserSelections).forEach(browser => {
                this.browserSelections[browser] = !allSelected;
            });
        },
        selectAllOS() {
            const allSelected = Object.values(this.osSelections).every(v => v);
            Object.keys(this.osSelections).forEach(os => {
                this.osSelections[os] = !allSelected;
            });
        },
        async loadLinkDetails() {
            this.linkId = localStorage.getItem('editLinkId');
            if (!this.linkId) {
                $store.app.setPage('links');
                return;
            }

            try {
                const formData = new FormData();
                formData.append('action', 'get_link_details');
                formData.append('id', this.linkId);

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    this.link_url = data.link.link_url;
                    this.urlredgrim_url = data.link.urlredgrim_url;
                    try {
                        const browsers = data.link.browser && data.link.browser !== '' ? JSON.parse(data.link.browser) : [];
                        const osSystems = data.link.os_system && data.link.os_system !== '' ? JSON.parse(data.link.os_system) : [];
                        
                        // Reset all selections
                        Object.keys(this.browserSelections).forEach(browser => {
                            this.browserSelections[browser] = browsers.includes(browser);
                        });
                        Object.keys(this.osSelections).forEach(os => {
                            this.osSelections[os] = osSystems.includes(os);
                        });
                    } catch (e) {
                        Object.keys(this.browserSelections).forEach(browser => {
                            this.browserSelections[browser] = false;
                        });
                        Object.keys(this.osSelections).forEach(os => {
                            this.osSelections[os] = false;
                        });
                    }
                    this.mobileOff = Boolean(parseInt(data.link.mobile_off));
                    this.desktopOff = Boolean(parseInt(data.link.desktop_off));
                    this.active = Boolean(parseInt(data.link.active));
                    this.js_url = data.link.js_url || '';
                    this.redirect_delay = parseInt(data.link.redirect_delay) || 0;
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: data.message || 'Link bilgileri yüklenemedi',
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        confirmButtonColor: '#9333ea',
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                            confirmButton: 'rounded-xl'
                        }
                    }).then(() => {
                        $store.app.setPage('links');
                    });
                }
            } catch (error) {
                console.error('Link bilgileri yüklenirken hata oluştu:', error);
                Swal.fire({
                    title: 'Hata!',
                    text: 'Link bilgileri yüklenirken bir hata oluştu',
                    icon: 'error',
                    confirmButtonText: 'Tamam',
                    confirmButtonColor: '#9333ea',
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: `rgba(147, 51, 234, 0.1)`,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                        confirmButton: 'rounded-xl'
                    }
                }).then(() => {
                    $store.app.setPage('links');
                });
            }
            this.loading = false;
        },
        async handleSubmit() {
            try {
                const formData = new FormData();
                formData.append('action', 'update_link');
                formData.append('id', this.linkId);
                formData.append('link_url', this.link_url);
                formData.append('urlredgrim_url', this.urlredgrim_url);
                formData.append('browser', JSON.stringify(this.browsers));
                formData.append('os_system', JSON.stringify(this.osSystems));
                formData.append('mobile_off', this.mobileOff ? 1 : 0);
                formData.append('desktop_off', this.desktopOff ? 1 : 0);
                formData.append('active', this.active ? 1 : 0);
                formData.append('redirect_delay', this.redirect_delay);

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    // Güncellenmiş değerleri senkronize et
                    this.mobileOff = data.link.mobile_off === 1;
                    this.desktopOff = data.link.desktop_off === 1;
                    this.active = data.link.active === 1;
                    this.redirect_delay = data.link.redirect_delay;

                    Swal.fire({
                        title: 'Başarılı!',
                        text: 'Link başarıyla güncellendi',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                        }
                    }).then(() => {
                        localStorage.removeItem('editLinkId');
                        $store.app.setPage('links');
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: data.message || 'Link güncellenirken bir hata oluştu',
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        confirmButtonColor: '#9333ea',
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                            confirmButton: 'rounded-xl'
                        }
                    });
                }
            } catch (error) {
                console.error('Link güncellenirken hata oluştu:', error);
            }
        },
        copyJsUrl(url) {
            navigator.clipboard.writeText(url).then(() => {
                Swal.fire({
                    title: 'Başarılı!',
                    text: 'JS URL kopyalandı',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: `rgba(147, 51, 234, 0.1)`,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                    }
                });
            }).catch(err => {
                console.error('JS URL kopyalanırken hata oluştu:', err);
                Swal.fire({
                    title: 'Hata!',
                    text: 'JS URL kopyalanırken bir hata oluştu',
                    icon: 'error',
                    confirmButtonText: 'Tamam',
                    confirmButtonColor: '#9333ea',
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: `rgba(147, 51, 234, 0.1)`,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                        confirmButton: 'rounded-xl'
                    }
                });
            });
        }
    }"
    x-init="
        loadLinkDetails();
        $store.app.currentPage = 'link-edit';
    ">

    <template x-if="loading">
        <div class="flex items-center justify-center py-20">
            <i class="fa-solid fa-circle-notch fa-spin text-3xl text-primary-500 dark:text-primary-400"></i>
            <span class="ml-2 text-gray-600 dark:text-gray-400">Yükleniyor...</span>
        </div>
    </template>

    <template x-if="!loading">
        <div>
            <div class="mb-6">
                <h2 class="text-xl font-secondary font-bold text-gray-800 dark:text-white">Link Düzenle</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Link bilgilerini güncelleyin</p>
            </div>

            <form @submit.prevent="handleSubmit" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Link URL -->
                    <div>
                        <label for="link_url" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Link URL</label>
                        <input type="url" id="link_url" x-model="link_url" required
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                            placeholder="https://example.com">
                    </div>

                    <!-- urlredgrim URL -->
                    <div>
                        <label for="urlredgrim_url" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Yönlenecek URL</label>
                        <input type="url" id="urlredgrim_url" x-model="urlredgrim_url" required
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                            placeholder="https://example.urlredgrim.com">
                    </div>

                    <!-- JS URL -->
                    <div class="md:col-span-2">
                        <label for="js_url" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">JS URL</label>
                        <div class="relative">
                            <input type="text" id="js_url" :value="window.location.origin + js_url" disabled
                                class="w-full px-4 py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 text-gray-400 dark:text-gray-600 cursor-not-allowed">
                            <button type="button" @click="copyJsUrl(window.location.origin + js_url)" 
                                class="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-amber-600 hover:text-amber-700 dark:text-amber-500 dark:hover:text-amber-400 transition-colors duration-200">
                                <i class="fa-regular fa-copy"></i>
                            </button>
                        </div>
                        <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Yönlendirme JS dosyası otomatik olarak oluşturulmuştur.</p>
                    </div>

                    <!-- Yönlendirme Süresi -->
                    <div class="md:col-span-2">
                        <label for="redirect_delay" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Yönlendirme Süresi (Saniye)</label>
                        <input type="number" id="redirect_delay" x-model="redirect_delay" min="0" required
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                            placeholder="0">
                        <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Yönlendirme için beklenecek süre (0 = anında yönlendirme)</p>
                    </div>

                    <!-- Browser ve OS System -->
                    <div class="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Browser -->
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tarayıcı Seçimi</label>
                                <button type="button" @click="selectAllBrowsers" class="text-sm font-medium text-primary-500 dark:text-primary-400 hover:text-primary-600 dark:hover:text-primary-500 transition-colors">
                                    <span x-text="browsers.length === 5 ? 'Seçimleri Temizle' : 'Tümünü Seç'"></span>
                                </button>
                            </div>
                            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="browser[]" value="chrome" class="peer sr-only" x-model="browserSelections.chrome">
                                    <i class="fa-brands fa-chrome text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Chrome</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="browser[]" value="firefox" class="peer sr-only" x-model="browserSelections.firefox">
                                    <i class="fa-brands fa-firefox-browser text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Firefox</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="browser[]" value="safari" class="peer sr-only" x-model="browserSelections.safari">
                                    <i class="fa-brands fa-safari text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Safari</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="browser[]" value="edge" class="peer sr-only" x-model="browserSelections.edge">
                                    <i class="fa-brands fa-edge text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Edge</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="browser[]" value="opera" class="peer sr-only" x-model="browserSelections.opera">
                                    <i class="fa-brands fa-opera text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Opera</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                            </div>
                        </div>

                        <!-- OS System -->
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">İşletim Sistemi Seçimi</label>
                                <button type="button" @click="selectAllOS" class="text-sm font-medium text-primary-500 dark:text-primary-400 hover:text-primary-600 dark:hover:text-primary-500 transition-colors">
                                    <span x-text="osSystems.length === 5 ? 'Seçimleri Temizle' : 'Tümünü Seç'"></span>
                                </button>
                            </div>
                            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="os_system[]" value="windows" class="peer sr-only" x-model="osSelections.windows">
                                    <i class="fa-brands fa-windows text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Windows</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="os_system[]" value="macos" class="peer sr-only" x-model="osSelections.macos">
                                    <i class="fa-brands fa-apple text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">MacOS</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="os_system[]" value="linux" class="peer sr-only" x-model="osSelections.linux">
                                    <i class="fa-brands fa-linux text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Linux</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="os_system[]" value="android" class="peer sr-only" x-model="osSelections.android">
                                    <i class="fa-brands fa-android text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Android</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                                <label class="relative flex items-center p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group">
                                    <input type="checkbox" name="os_system[]" value="ios" class="peer sr-only" x-model="osSelections.ios">
                                    <i class="fa-brands fa-app-store-ios text-xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                    <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">iOS</span>
                                    <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Platform Seçimi -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Platform Seçimi</label>
                        <div class="grid grid-cols-2 gap-4">
                            <label class="relative flex items-center p-4 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group"
                                :class="{'opacity-50 cursor-not-allowed': desktopOff}">
                                <input type="checkbox" name="mobile_off" class="peer sr-only" x-model="mobileOff" :disabled="desktopOff"
                                    @change="if(mobileOff && desktopOff) desktopOff = false">
                                <i class="fa-solid fa-mobile-screen-button text-2xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Mobil Kapalı</span>
                                <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                            </label>
                            <label class="relative flex items-center p-4 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors group"
                                :class="{'opacity-50 cursor-not-allowed': mobileOff}">
                                <input type="checkbox" name="desktop_off" class="peer sr-only" x-model="desktopOff" :disabled="mobileOff"
                                    @change="if(mobileOff && desktopOff) mobileOff = false">
                                <i class="fa-solid fa-desktop text-2xl text-gray-400 dark:text-gray-500 group-hover:text-primary-500 dark:group-hover:text-primary-400 peer-checked:text-primary-500 dark:peer-checked:text-primary-400 transition-colors"></i>
                                <span class="ml-3 text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white peer-checked:text-gray-900 dark:peer-checked:text-white transition-colors">Masaüstü Kapalı</span>
                                <span class="absolute inset-0 border-2 border-transparent peer-checked:border-primary-500 dark:peer-checked:border-primary-400 rounded-xl transition-colors"></span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Aktif/Pasif Switch -->
                <div class="border-t border-gray-200 dark:border-gray-700 pt-6 flex items-center justify-between">
                    <div>
                        <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300">Link Durumu</h3>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Linkin aktif olup olmadığını belirleyin</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="active" class="sr-only peer" x-model="active">
                        <div class="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-500/20 dark:peer-focus:ring-primary-400/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-primary-500 dark:peer-checked:bg-primary-400"></div>
                        <span class="ml-3 text-sm font-medium text-gray-700 dark:text-gray-300">Aktif</span>
                    </label>
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="button" @click="$store.app.setPage('links')"
                        class="inline-flex items-center px-6 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-xl transition-colors duration-200">
                        <i class="fa-solid fa-xmark mr-2"></i>
                        İptal
                    </button>
                    <button type="submit"
                        class="inline-flex items-center px-6 py-3 text-sm font-medium text-white bg-primary-500 dark:bg-primary-400 hover:bg-primary-600 dark:hover:bg-primary-500 rounded-xl transition-colors duration-200">
                        <i class="fa-solid fa-check mr-2"></i>
                        Güncelle
                    </button>
                </div>
            </form>
        </div>
    </template>
</div> 