<div class="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4">
    <div class="bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl p-6 sm:p-8 rounded-3xl shadow-2xl w-full max-w-md border border-white/20 dark:border-white/10" 
         x-data="{ 
            username: '', 
            password: '', 
            remember: false,
            handleSubmit() {
                const formData = new FormData();
                formData.append('action', 'login');
                formData.append('username', this.username);
                formData.append('password', this.password);
                formData.append('remember', this.remember);

                fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: 'Başarılı!',
                            text: 'Giriş başarılı, yönlendiriliyorsunuz...',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 1500,
                            background: 'rgba(255, 255, 255, 0.95)',
                            backdrop: `rgba(147, 51, 234, 0.1)`,
                            customClass: {
                                popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                                icon: 'border-0 !bg-transparent'
                            },
                            showClass: {
                                popup: 'animate__animated animate__fadeIn animate__faster'
                            },
                            hideClass: {
                                popup: 'animate__animated animate__fadeOut animate__faster'
                            },
                            didOpen: () => {
                                setTimeout(() => {
                                    window.location.href = '/dashboard';
                                }, 1000);
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Hata!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonText: 'Tamam',
                            confirmButtonColor: '#9333ea',
                            background: 'rgba(255, 255, 255, 0.95)',
                            backdrop: `rgba(147, 51, 234, 0.1)`,
                            customClass: {
                                popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                                confirmButton: 'rounded-xl',
                                icon: 'border-0 !bg-transparent'
                            },
                            showClass: {
                                popup: 'animate__animated animate__fadeIn animate__faster'
                            },
                            hideClass: {
                                popup: 'animate__animated animate__fadeOut animate__faster'
                            }
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Bir bağlantı hatası oluştu. Lütfen tekrar deneyin.',
                        icon: 'error'
                    });
                });
            }
         }">
        <div class="text-center mb-6 sm:mb-8">
            <div class="inline-flex p-4 sm:p-5 rounded-full bg-gradient-to-br from-primary-100 to-primary-50 dark:from-primary-900/50 dark:to-primary-800/50 mb-4 sm:mb-6 ring-[3px] ring-primary-200/50 dark:ring-primary-900/50">
                <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center">
                    <i class="fa-solid fa-user text-4xl sm:text-5xl text-primary-500/90 dark:text-primary-400/90"></i>
                </div>
            </div>
            <h2 class="text-2xl sm:text-3xl font-secondary font-bold text-gray-800 dark:text-white mb-2 sm:mb-3">Hoş Geldiniz</h2>
            <div class="space-y-1">
                <p class="text-sm sm:text-base font-medium text-gray-700 dark:text-gray-300">Hesabınıza giriş yapın</p>
                <p class="text-xs sm:text-sm text-gray-500 dark:text-gray-400 font-primary">urlredgrimJs Oto Yönlendirme V1</p>
            </div>
        </div>
        
        <form @submit.prevent="handleSubmit" class="space-y-4 sm:space-y-5">
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-user text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="text" 
                    x-model="username"
                    class="block w-full pl-11 pr-4 py-3.5 sm:py-4 text-sm sm:text-base border-2 border-gray-100 dark:border-gray-700 rounded-xl sm:rounded-2xl bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Kullanıcı Adı"
                    required
                >
            </div>
            
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i class="fa-solid fa-lock text-gray-400 dark:text-gray-500 group-focus-within:text-primary-500 dark:group-focus-within:text-primary-400 transition-colors duration-200"></i>
                </div>
                <input 
                    type="password" 
                    x-model="password"
                    class="block w-full pl-11 pr-4 py-3.5 sm:py-4 text-sm sm:text-base border-2 border-gray-100 dark:border-gray-700 rounded-xl sm:rounded-2xl bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Şifre"
                    required
                >
            </div>
            
            <div class="flex items-center">
                <label class="flex items-center">
                    <div class="relative inline-flex items-center">
                        <input type="checkbox" x-model="remember" class="peer sr-only">
                        <div class="w-10 sm:w-11 h-5 sm:h-6 bg-gray-200 dark:bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-500/20 dark:peer-focus:ring-primary-400/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 dark:after:border-gray-600 after:border after:rounded-full after:h-4 sm:after:h-5 after:w-4 sm:after:w-5 after:transition-all peer-checked:bg-primary-500 dark:peer-checked:bg-primary-400"></div>
                        <span class="ml-3 text-sm font-medium text-gray-600 dark:text-gray-400">Beni Hatırla</span>
                    </div>
                </label>
            </div>
            
            <div class="pt-2 sm:pt-3">
                <button 
                    type="submit"
                    class="relative w-full inline-flex items-center justify-center px-6 sm:px-8 py-3.5 sm:py-4 text-sm sm:text-base font-secondary font-semibold text-white bg-gradient-to-r from-primary-600 to-primary-500 dark:from-primary-500 dark:to-primary-400 hover:from-primary-700 hover:to-primary-600 dark:hover:from-primary-600 dark:hover:to-primary-500 rounded-xl sm:rounded-2xl transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-4 focus:ring-primary-500/20 dark:focus:ring-primary-400/20 shadow-lg shadow-primary-500/20 dark:shadow-primary-400/20 group"
                >
                    <i class="fa-solid fa-arrow-right-to-arc absolute left-3 sm:left-4 text-lg sm:text-xl opacity-90 group-hover:translate-x-1 transition-transform"></i>
                    <span class="inline-flex items-center">
                        Giriş Yap
                        <i class="fa-solid fa-chevron-right ml-2 text-sm opacity-80"></i>
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>
