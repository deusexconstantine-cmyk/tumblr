<!-- Linkler Tablosu -->
<div class="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl border border-gray-200 dark:border-gray-700 p-6"
    x-data="{
        links: [],
        loading: true,
        currentPage: 1,
        totalPages: 1,
        search: '',
        async copyJsUrl(url) {
            try {
                const scriptTag = `<script src='${url}'></script>`;
                await navigator.clipboard.writeText(scriptTag);
                
                Swal.fire({
                    icon: 'success',
                    title: 'Kopyalandı!',
                    text: 'Script etiketi başarıyla kopyalandı',
                    showConfirmButton: false,
                    timer: 2000,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: false,
                    customClass: {
                        popup: 'rounded-xl shadow-lg dark:!bg-gray-800/95 dark:text-white'
                    },
                    toast: true,
                    position: 'bottom-end'
                });
            } catch (error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Hata!',
                    text: 'Kopyalama işlemi başarısız oldu',
                    showConfirmButton: false,
                    timer: 2000,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: false,
                    customClass: {
                        popup: 'rounded-xl shadow-lg dark:!bg-gray-800/95 dark:text-white'
                    },
                    toast: true,
                    position: 'bottom-end'
                });
            }
        },
        formatTimeAgo(date) {
            const now = new Date();
            const past = new Date(date);
            const diff = Math.abs(now - past);
            const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
            
            if (diffDays >= 1) {
                return past.toLocaleString('tr-TR');
            }
            
            const diffHours = Math.floor(diff / (1000 * 60 * 60));
            if (diffHours >= 1) {
                return `${diffHours} s önce`;
            }
            
            const diffMinutes = Math.floor(diff / (1000 * 60));
            if (diffMinutes >= 1) {
                return `${diffMinutes} dk önce`;
            }
            
            const diffSeconds = Math.floor(diff / 1000);
            return `${diffSeconds} sn önce`;
        },
        async loadLinks(page = 1) {
            this.loading = true;
            try {
                const formData = new FormData();
                formData.append('action', 'get_links');
                formData.append('page', page);
                formData.append('search', this.search);

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    this.links = data.links;
                    this.currentPage = data.current_page;
                    this.totalPages = data.total_pages;
                }
            } catch (error) {
                console.error('Linkler yüklenirken hata oluştu:', error);
            }
            this.loading = false;
        },
        async toggleStatus(id, currentStatus) {
            try {
                const formData = new FormData();
                formData.append('action', 'toggle_link_status');
                formData.append('id', id);
                formData.append('status', currentStatus ? 0 : 1);

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    await this.loadLinks(this.currentPage);
                    Swal.fire({
                        title: 'Başarılı!',
                        text: 'Link durumu güncellendi',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdrop: `rgba(147, 51, 234, 0.1)`,
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                        }
                    });
                }
            } catch (error) {
                console.error('Link durumu güncellenirken hata oluştu:', error);
            }
        },
        async deleteLink(id) {
            const result = await Swal.fire({
                title: 'Emin misiniz?',
                text: 'Bu link kalıcı olarak silinecek!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Evet, Sil',
                cancelButtonText: 'İptal',
                confirmButtonColor: '#9333ea',
                background: 'rgba(255, 255, 255, 0.95)',
                backdrop: `rgba(147, 51, 234, 0.1)`,
                customClass: {
                    popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white',
                    confirmButton: 'rounded-xl',
                    cancelButton: 'rounded-xl'
                }
            });

            if (result.isConfirmed) {
                try {
                    const formData = new FormData();
                    formData.append('action', 'delete_link');
                    formData.append('id', id);

                    const response = await fetch('/includes/api.php', {
                        method: 'POST',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: formData
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        await this.loadLinks(this.currentPage);
                        Swal.fire({
                            title: 'Başarılı!',
                            text: 'Link başarıyla silindi',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 1500,
                            background: 'rgba(255, 255, 255, 0.95)',
                            backdrop: `rgba(147, 51, 234, 0.1)`,
                            customClass: {
                                popup: 'rounded-2xl shadow-2xl dark:!bg-gray-800/95 dark:text-white'
                            }
                        });
                    }
                } catch (error) {
                    console.error('Link silinirken hata oluştu:', error);
                }
            }
        }
    }"
    x-init="
        loadLinks();
        $store.app.currentPage = 'links';
    ">
    
    <!-- Başlık ve Arama -->
    <div class="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
        <div class="flex items-center gap-4">
            <button @click="$store.app.setPage('link-add')" 
                class="w-10 h-10 flex items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-primary-600 dark:from-primary-600 dark:to-primary-700 hover:from-primary-600 hover:to-primary-700 dark:hover:from-primary-700 dark:hover:to-primary-800 text-white shadow-lg shadow-primary-500/20 dark:shadow-primary-700/20 transform hover:scale-110 transition-all duration-200">
                <i class="fa-solid fa-plus"></i>
            </button>
            <div>
                <h2 class="text-xl font-secondary font-bold text-gray-800 dark:text-white">Linkler</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Tüm linkleri görüntüle ve yönet</p>
            </div>
        </div>
        <div class="w-full sm:w-auto">
            <div class="relative">
                <input type="text" x-model="search" @input.debounce.300ms="loadLinks(1)"
                    class="w-full sm:w-64 pl-10 pr-4 py-2 rounded-xl border-2 border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500 dark:focus:border-primary-400 focus:ring-4 focus:ring-primary-500/10 dark:focus:ring-primary-400/10 transition-all duration-200"
                    placeholder="Link ara...">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i class="fa-solid fa-search text-gray-400 dark:text-gray-500"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Tablo -->
    <div class="relative overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="text-xs text-gray-700 dark:text-gray-300 bg-gray-50/50 dark:bg-gray-700/50">
                <tr>
                    <th class="px-6 py-3 rounded-l-xl">
                        <div class="flex items-center">
                            <i class="fa-regular fa-calendar text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>Eklenme Tarihi</span>
                        </div>
                    </th>
                    <th class="px-6 py-3">
                        <div class="flex items-center">
                            <i class="fa-solid fa-link text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>Link URL</span>
                        </div>
                    </th>
                    <th class="px-6 py-3">
                        <div class="flex items-center">
                            <i class="fa-solid fa-arrow-up-right-from-square text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>URL</span>
                        </div>
                    </th>
                    <th class="px-6 py-3">
                        <div class="flex items-center">
                            <i class="fa-solid fa-code text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>JS URL</span>
                        </div>
                    </th>
                    <th class="px-6 py-3 rounded-r-xl">
                        <div class="flex items-center">
                            <i class="fa-solid fa-gear text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>İşlemler</span>
                        </div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <template x-if="loading">
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center">
                            <div class="flex items-center justify-center">
                                <i class="fa-solid fa-circle-notch fa-spin text-2xl text-primary-500 dark:text-primary-400"></i>
                                <span class="ml-2 text-gray-600 dark:text-gray-400">Yükleniyor...</span>
                            </div>
                        </td>
                    </tr>
                </template>
                <template x-if="!loading && links.length === 0">
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                            Henüz link eklenmemiş
                        </td>
                    </tr>
                </template>
                <template x-for="link in links" :key="link.id">
                    <tr class="border-b border-gray-200 dark:border-gray-700">
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-regular fa-calendar text-primary-500 dark:text-primary-400 mr-2"></i>
                                <span x-text="formatTimeAgo(link.add_date)"></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-link text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="link.link_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="link.link_url"></a>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-arrow-up-right-from-square text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="link.urlredgrim_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="link.urlredgrim_url"></a>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-code text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="window.location.origin + link.js_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="window.location.origin + link.js_url"></a>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-2">
                                <a :href="'/preview.php?id=' + link.id" target="_blank"
                                    class="p-2 text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors duration-200">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <button @click="$store.app.setPage('link-edit'); localStorage.setItem('editLinkId', link.id)"
                                    class="p-2 text-primary-500 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors duration-200">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                <button @click="copyJsUrl(window.location.origin + link.js_url)" 
                                    class="p-2 text-amber-600 hover:text-amber-700 dark:text-amber-500 dark:hover:text-amber-600 transition-colors duration-200">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                                <button @click="deleteLink(link.id)"
                                    class="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors duration-200">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </template>
            </tbody>
        </table>
    </div>

    <!-- Sayfalama -->
    <div class="flex items-center justify-between mt-6">
        <div class="text-sm text-gray-600 dark:text-gray-400">
            <span x-text="links.length"></span> link gösteriliyor
        </div>
        <div class="flex items-center space-x-2">
            <button @click="loadLinks(currentPage - 1)" :disabled="currentPage === 1"
                class="px-3 py-1 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 dark:hover:bg-gray-700">
                <i class="fa-solid fa-chevron-left"></i>
            </button>
            <span class="text-sm text-gray-600 dark:text-gray-400">
                Sayfa <span x-text="currentPage"></span> / <span x-text="totalPages"></span>
            </span>
            <button @click="loadLinks(currentPage + 1)" :disabled="currentPage === totalPages"
                class="px-3 py-1 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 dark:hover:bg-gray-700">
                <i class="fa-solid fa-chevron-right"></i>
            </button>
        </div>
    </div>
</div> 