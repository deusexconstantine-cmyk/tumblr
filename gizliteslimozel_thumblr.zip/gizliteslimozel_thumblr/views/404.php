<div class="min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center p-4">
    <div class="text-center">
        <div class="inline-flex p-4 rounded-full bg-red-50 dark:bg-red-900/50 mb-6">
            <div class="w-16 h-16 flex items-center justify-center">
                <i class="fa-solid fa-triangle-exclamation text-4xl text-red-500 dark:text-red-400"></i>
            </div>
        </div>
        <h1 class="text-4xl sm:text-5xl font-secondary font-bold text-gray-800 dark:text-white mb-4">404</h1>
        <h2 class="text-xl sm:text-2xl font-secondary font-semibold text-gray-700 dark:text-gray-200 mb-2">Sayfa Bulunamadı</h2>
        <p class="text-sm sm:text-base text-gray-600 dark:text-gray-400 mb-8">Aradığınız sayfa bulunamadı veya taşınmış olabilir.</p>
        
        <button 
            @click="$store.app.setPage('dashboard')"
            class="inline-flex items-center px-6 py-3 text-sm font-medium text-white bg-gradient-to-br from-primary-500 via-primary-600 to-primary-500 hover:from-primary-600 hover:via-primary-700 hover:to-primary-600 rounded-xl shadow-lg shadow-primary-500/20 transform hover:-translate-y-0.5 transition-all duration-200"
        >
            <i class="fa-solid fa-home mr-2"></i>
            Ana Sayfaya Dön
        </button>
    </div>
</div> 