<!-- İstatistik Kartları -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6"
    x-data="{
        links: [],
        loading: true,
        getActiveLinks() {
            return this.links.filter(link => parseInt(link.active) === 1).length;
        },
        getMobileActiveLinks() {
            return this.links.filter(link => parseInt(link.active) === 1 && parseInt(link.desktop_off) === 1).length;
        },
        getDesktopActiveLinks() {
            return this.links.filter(link => parseInt(link.active) === 1 && parseInt(link.mobile_off) === 1).length;
        },
        async loadStats() {
            this.loading = true;
            try {
                const formData = new FormData();
                formData.append('action', 'get_links');

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    this.links = data.links;
                    console.log('Tüm Linkler:', this.links);
                    console.log('Mobilde Aktif:', this.links.filter(link => parseInt(link.active) === 1 && parseInt(link.desktop_off) === 1));
                    console.log('Masaüstünde Aktif:', this.links.filter(link => parseInt(link.active) === 1 && parseInt(link.mobile_off) === 1));
                }
            } catch (error) {
                console.error('İstatistikler yüklenirken hata oluştu:', error);
            }
            this.loading = false;
        }
    }"
    x-init="loadStats()">
    <!-- Toplam Link -->
    <div class="relative group">
        <div class="absolute inset-0 bg-gradient-to-br from-primary-500/10 to-primary-600/10 dark:from-primary-500/5 dark:to-primary-600/5 rounded-xl blur-sm transition-all duration-300"></div>
        <div class="relative p-5 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 transition-all duration-300 group-hover:translate-y-[-2px]">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-primary-500 to-primary-600 dark:from-primary-600 dark:to-primary-700 flex items-center justify-center">
                    <i class="fa-solid fa-link text-xl text-white"></i>
                </div>
                <button @click="$store.app.setPage('link-add')" 
                    class="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-primary-800/50 transition-all duration-200">
                    <i class="fa-solid fa-plus"></i>
                </button>
            </div>
            <template x-if="loading">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full border-3 border-primary-500/20 border-t-primary-500 animate-spin"></div>
                    <span class="text-sm text-gray-500">Yükleniyor...</span>
                </div>
            </template>
            <template x-if="!loading">
                <div>
                    <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-1" x-text="links.length"></h3>
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Toplam Link</p>
                </div>
            </template>
        </div>
    </div>

    <!-- Aktif Link -->
    <div class="relative group">
        <div class="absolute inset-0 bg-gradient-to-br from-green-500/10 to-green-600/10 dark:from-green-500/5 dark:to-green-600/5 rounded-xl blur-sm transition-all duration-300"></div>
        <div class="relative p-5 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 transition-all duration-300 group-hover:translate-y-[-2px]">
            <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-green-600 dark:from-green-600 dark:to-green-700 flex items-center justify-center mb-4">
                <i class="fa-solid fa-toggle-on text-xl text-white"></i>
            </div>
            <template x-if="loading">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full border-3 border-green-500/20 border-t-green-500 animate-spin"></div>
                    <span class="text-sm text-gray-500">Yükleniyor...</span>
                </div>
            </template>
            <template x-if="!loading">
                <div>
                    <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-1" x-text="getActiveLinks()"></h3>
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Aktif Link</p>
                </div>
            </template>
        </div>
    </div>

    <!-- Mobil Aktif -->
    <div class="relative group">
        <div class="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-blue-600/10 dark:from-blue-500/5 dark:to-blue-600/5 rounded-xl blur-sm transition-all duration-300"></div>
        <div class="relative p-5 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 transition-all duration-300 group-hover:translate-y-[-2px]">
            <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 dark:from-blue-600 dark:to-blue-700 flex items-center justify-center mb-4">
                <i class="fa-solid fa-mobile-screen-button text-xl text-white"></i>
            </div>
            <template x-if="loading">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full border-3 border-blue-500/20 border-t-blue-500 animate-spin"></div>
                    <span class="text-sm text-gray-500">Yükleniyor...</span>
                </div>
            </template>
            <template x-if="!loading">
                <div>
                    <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-1" x-text="getMobileActiveLinks()"></h3>
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Sadece Mobilde Aktif</p>
                </div>
            </template>
        </div>
    </div>

    <!-- Masaüstü Aktif -->
    <div class="relative group">
        <div class="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-amber-600/10 dark:from-amber-500/5 dark:to-amber-600/5 rounded-xl blur-sm transition-all duration-300"></div>
        <div class="relative p-5 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 transition-all duration-300 group-hover:translate-y-[-2px]">
            <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-amber-500 to-amber-600 dark:from-amber-600 dark:to-amber-700 flex items-center justify-center mb-4">
                <i class="fa-solid fa-desktop text-xl text-white"></i>
            </div>
            <template x-if="loading">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full border-3 border-amber-500/20 border-t-amber-500 animate-spin"></div>
                    <span class="text-sm text-gray-500">Yükleniyor...</span>
                </div>
            </template>
            <template x-if="!loading">
                <div>
                    <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-1" x-text="getDesktopActiveLinks()"></h3>
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Sadece Masaüstünde Aktif</p>
                </div>
            </template>
        </div>
    </div>
</div>

<!-- Recent links table -->
<div class="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl border border-gray-200 dark:border-gray-700"
    x-data="{
        links: [],
        loading: true,
        formatTimeAgo(date) {
            const now = new Date();
            const past = new Date(date);
            const diff = Math.abs(now - past);
            const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
            
            if (diffDays >= 1) {
                return past.toLocaleString('tr-TR');
            }
            
            const diffHours = Math.floor(diff / (1000 * 60 * 60));
            if (diffHours >= 1) {
                return `${diffHours} s önce`;
            }
            
            const diffMinutes = Math.floor(diff / (1000 * 60));
            if (diffMinutes >= 1) {
                return `${diffMinutes} dk önce`;
            }
            
            const diffSeconds = Math.floor(diff / 1000);
            return `${diffSeconds} sn önce`;
        },
        async loadLinks() {
            this.loading = true;
            try {
                const formData = new FormData();
                formData.append('action', 'get_links');
                formData.append('limit', 10);

                const response = await fetch('/includes/api.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    this.links = data.links;
                }
            } catch (error) {
                console.error('Linkler yüklenirken hata oluştu:', error);
            }
            this.loading = false;
        }
    }"
    x-init="loadLinks()">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-secondary font-bold text-gray-800 dark:text-white">Son Eklenen Linkler</h2>
        <button @click="$store.app.setPage('links')" class="inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400 hover:underline group">
            <i class="fa-solid fa-eye mr-2"></i>
            <span>Tümünü Gör</span>
            <i class="fa-solid fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
        </button>
    </div>
    <div class="relative overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 dark:text-gray-300 bg-gray-50/50 dark:bg-gray-700/50">
                <tr>
                    <th scope="col" class="px-6 py-3 rounded-l-xl">
                        <div class="flex items-center">
                            <i class="fa-regular fa-calendar text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>Eklenme Tarihi</span>
                        </div>
                    </th>
                    <th scope="col" class="px-6 py-3">
                        <div class="flex items-center">
                            <i class="fa-solid fa-link text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>Link URL</span>
                        </div>
                    </th>
                    <th scope="col" class="px-6 py-3">
                        <div class="flex items-center">
                            <i class="fa-solid fa-arrow-up-right-from-square text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>Yönlenecek URL</span>
                        </div>
                    </th>
                    <th scope="col" class="px-6 py-3 rounded-r-xl">
                        <div class="flex items-center">
                            <i class="fa-solid fa-code text-primary-500 dark:text-primary-400 mr-2"></i>
                            <span>JS URL</span>
                        </div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <template x-if="loading">
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center">
                            <div class="flex items-center justify-center">
                                <i class="fa-solid fa-circle-notch fa-spin text-2xl text-primary-500 dark:text-primary-400"></i>
                                <span class="ml-2 text-gray-600 dark:text-gray-400">Yükleniyor...</span>
                            </div>
                        </td>
                    </tr>
                </template>
                <template x-if="!loading && links.length === 0">
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                            Henüz link eklenmemiş
                        </td>
                    </tr>
                </template>
                <template x-for="link in links" :key="link.id">
                    <tr class="border-b border-gray-200 dark:border-gray-700">
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-regular fa-calendar text-primary-500 dark:text-primary-400 mr-2"></i>
                                <span x-text="formatTimeAgo(link.add_date)"></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-link text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="link.link_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="link.link_url"></a>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-arrow-up-right-from-square text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="link.urlredgrim_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="link.urlredgrim_url"></a>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-900 dark:text-white">
                            <div class="flex items-center">
                                <i class="fa-solid fa-code text-primary-500 dark:text-primary-400 mr-2"></i>
                                <a :href="window.location.origin + link.js_url" target="_blank" class="hover:text-primary-500 dark:hover:text-primary-400 transition-colors duration-200" x-text="window.location.origin + link.js_url"></a>
                            </div>
                        </td>
                    </tr>
                </template>
            </tbody>
        </table>
    </div>
</div> 