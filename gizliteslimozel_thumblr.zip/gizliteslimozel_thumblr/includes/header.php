<!DOCTYPE html>
<html lang="tr" x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }" x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))" :class="{ 'dark': darkMode }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">

    <?php
    // Router'dan sayfa bilgilerini al
    $router = Router::getInstance();
    $title = $router->getTitle();
    $description = $router->getDescription();
    ?>
    <title><?php echo $title; ?> - urlredgrimJs</title>
    <meta name="description" content="<?php echo $description; ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#faf5ff',
                            100: '#f3e8ff',
                            200: '#e9d5ff',
                            300: '#d8b4fe',
                            400: '#c084fc',
                            500: '#a855f7',
                            600: '#9333ea',
                            700: '#7e22ce',
                            800: '#6b21a8',
                            900: '#581c87'
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        roboto: ['Roboto', 'sans-serif'],
                        opensans: ['Open Sans', 'sans-serif']
                    },
                }
            }
        }
    </script>
    <style>
        :root {
            --font-primary: 'Inter', sans-serif;
            --font-secondary: 'Roboto', sans-serif;
            --font-tertiary: 'Open Sans', sans-serif;
        }

        body {
            font-family: var(--font-primary);
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: var(--font-secondary);
        }

        .font-primary { font-family: var(--font-primary); }
        .font-secondary { font-family: var(--font-secondary); }
        .font-tertiary { font-family: var(--font-tertiary); }
    </style>
    <!-- Alpine.js -->
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Sweet Alert 2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* SweetAlert2 için özel stil */
        .swal2-popup {
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .dark .swal2-popup {
            background: rgba(31, 41, 55, 0.95) !important;
        }
        .dark .swal2-title,
        .dark .swal2-content {
            color: #fff !important;
        }
        .dark .swal2-close {
            color: #fff;
        }
    </style>
    <script>
        // SweetAlert2 varsayılan ayarları
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            background: 'rgba(255, 255, 255, 0.95)',
            backdrop: false,
            customClass: {
                popup: 'rounded-xl shadow-xl'
            }
        });

        // SweetAlert2 varsayılan ayarları
        Swal.mixin({
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                confirmButton: 'rounded-xl'
            },
            confirmButtonColor: '#9333ea',
            background: 'rgba(255, 255, 255, 0.95)',
            backdrop: `rgba(147, 51, 234, 0.1)`,
            showClass: {
                popup: 'animate__animated animate__fadeIn animate__faster'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOut animate__faster'
            }
        });

        document.addEventListener('alpine:init', () => {
            Alpine.store('app', {
                currentPage: 'link-add',
                setPage(page) {
                    this.currentPage = page;
                    // Sayfa değişikliğini yönet
                    if (page === 'dashboard') {
                        window.location.href = '/';
                    }
                }
            });
        });
    </script>
</head>
<body class="bg-gradient-to-br from-primary-50 via-white to-primary-100 dark:from-gray-900 dark:via-gray-800 dark:to-primary-900 min-h-screen font-sans relative">
    <div class="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\"30\" height=\"30\" viewBox=\"0 0 30 30\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cpath d=\"M1.22676 0C1.91374 0 2.45351 0.539773 2.45351 1.22676C2.45351 1.91374 1.91374 2.45351 1.22676 2.45351C0.539773 2.45351 0 1.91374 0 1.22676C0 0.539773 0.539773 0 1.22676 0Z\" fill=\"rgba(147,51,234,0.07)\"%3E%3C/path%3E%3C/svg%3E')] opacity-50 dark:opacity-30"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-primary-100/20 via-transparent to-primary-50/20 dark:from-primary-900/30 dark:via-transparent dark:to-primary-800/30 backdrop-blur-[100px]"></div>
    <div class="relative min-h-screen overflow-y-auto">
        <!-- Tema Değiştirme Butonu -->
        <button 
            @click="darkMode = !darkMode" 
            class="fixed top-6 right-6 w-12 h-12 hidden sm:flex items-center justify-center rounded-full bg-white/90 dark:bg-gray-800/90 shadow-lg backdrop-blur-sm hover:scale-110 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-primary-500/20 dark:focus:ring-primary-400/20 z-50 border border-gray-100/50 dark:border-white/10 group"
            :class="darkMode ? 'hover:bg-gray-700/90' : 'hover:bg-gray-50/90'"
        >
            <i class="fa-solid fa-sun text-lg text-amber-500 dark:hidden transition-transform duration-500 group-hover:rotate-45"></i>
            <i class="fa-solid fa-moon text-lg text-primary-400 hidden dark:inline-block transition-transform duration-500 group-hover:-rotate-12"></i>
        </button>
        <main class="container mx-auto px-4 py-6"> 