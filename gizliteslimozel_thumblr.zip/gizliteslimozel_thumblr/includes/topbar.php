<!-- Top bar -->
<div class="mb-4 sm:mb-6 p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-xl sm:rounded-2xl border border-gray-200 dark:border-gray-700">
    <div class="flex items-center justify-between">
        <!-- Sol Kısım - Başlık ve Menü -->
        <div class="flex items-center space-x-3 sm:space-x-4">
            <button @click="$store.app.toggleSidebar()" 
                class="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-lg sm:rounded-xl bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-primary-800/50 transition-all duration-200 group">
                <i class="fa-solid" :class="$store.app.sidebarOpen ? 'fa-bars-staggered' : 'fa-bars'"></i>
            </button>
            
            <!-- Geri Dön Butonu -->
            <button onclick="history.back()" class="hidden sm:flex w-8 h-8 items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400 hover:bg-primary-200 dark:hover:bg-primary-800/50 transition-colors duration-200">
                <i class="fa-solid fa-arrow-left text-sm"></i>
            </button>

            <h1 class="text-lg sm:text-xl font-secondary font-bold text-gray-800 dark:text-white" x-text="$store.app.currentPage === 'dashboard' ? 'Dashboard' : 
                $store.app.currentPage === 'link-add' ? 'Link Ekle' : 
                $store.app.currentPage === 'links' ? 'Linkler' :
                $store.app.currentPage === 'link-edit' ? 'Link Düzenle' :
                $store.app.currentPage === 'settings' ? 'Ayarlar' :
                $store.app.currentPage === 'login' ? 'Giriş Yap' :
                $store.app.currentPage === '404' ? 'Sayfa Bulunamadı' : '404'">
            </h1>
        </div>

        <!-- Sağ Kısım - Kullanıcı Bilgileri -->
        <div class="flex items-center space-x-2 sm:space-x-3">
            <div class="text-right hidden sm:block">
                <p class="text-sm font-medium text-gray-900 dark:text-white">
                    <?php echo isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'Error'; ?>
                </p>
                <p class="text-xs text-gray-500 dark:text-gray-400">urlredgrimJS</p>
            </div>
            <button @click="$store.app.setPage('settings')" class="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-primary-100 dark:bg-primary-900/50 hover:bg-primary-200 dark:hover:bg-primary-800/50 flex items-center justify-center transition-colors duration-200 group">
                <i class="fa-solid fa-gear text-primary-600 dark:text-primary-400 group-hover:rotate-90 transition-transform duration-500"></i>
            </button>
            <button onclick="handleLogout()" class="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 dark:from-primary-600 dark:to-primary-700 hover:from-primary-600 hover:to-primary-700 dark:hover:from-primary-700 dark:hover:to-primary-800 flex items-center justify-center text-white shadow-lg shadow-primary-500/20 dark:shadow-primary-700/20 transform hover:scale-110 transition-all duration-200">
                <i class="fa-solid fa-right-from-bracket text-sm"></i>
            </button>
        </div>
    </div>
</div> 