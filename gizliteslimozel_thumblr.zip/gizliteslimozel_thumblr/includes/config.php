<?php
// Hata raporlamayı aktif et
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Zaman dilimini ayarla
date_default_timezone_set('Europe/Istanbul');

// .env dosyasını oku
function loadEnv($path = null) {
    if ($path === null) {
        $path = __DIR__ . '/../.env';
    }
    
    if(!file_exists($path)) {
        throw new Exception('.env dosyası bulunamadı: ' . $path);
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            
            if (!array_key_exists($key, $_ENV)) {
                putenv(sprintf('%s=%s', $key, $value));
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

// .env dosyasını yükle
loadEnv();

// Veritabanı bağlantı sınıfı
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            // PDO bağlantı seçenekleri
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES '" . getenv('DB_CHARSET') . "' COLLATE '" . getenv('DB_COLLATE') . "'"
            ];

            // PDO bağlantısını oluştur
            $this->connection = new PDO(
                "mysql:host=" . getenv('DB_HOST') . ";dbname=" . getenv('DB_NAME') . ";charset=" . getenv('DB_CHARSET'),
                getenv('DB_USER'),
                getenv('DB_PASS'),
                $options
            );

            // Türkçe karakter ve zaman ayarları
            $this->connection->exec("SET CHARACTER SET " . getenv('DB_CHARSET'));
            $this->connection->exec("SET NAMES " . getenv('DB_CHARSET'));
            $this->connection->exec("SET COLLATION_CONNECTION = '" . getenv('DB_COLLATE') . "'");
            $this->connection->exec("SET time_zone = '+03:00'");

        } catch(PDOException $e) {
            throw new Exception("Veritabanı bağlantı hatası: " . $e->getMessage());
        }
    }

    // Singleton pattern - tek instance oluştur
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Bağlantıyı getir
    public function getConnection() {
        return $this->connection;
    }

    // Singleton pattern için clone'lamayı engelle
    private function __clone() {}

    // Singleton pattern için unserialize'i engelle
    private function __wakeup() {}
}

// Global veritabanı bağlantısı fonksiyonu
function db() {
    return Database::getInstance()->getConnection();
}

// Örnek kullanım:
// $db = db();
// $query = $db->query("SELECT * FROM users");
// $users = $query->fetchAll();
?> 