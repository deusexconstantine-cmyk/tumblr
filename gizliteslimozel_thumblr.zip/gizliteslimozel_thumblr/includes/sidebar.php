<!-- Sidebar -->
<aside class="fixed top-0 left-0 z-40 h-screen transition-transform duration-300 w-full sm:w-72" 
    x-cloak
    :class="{ 
        '-translate-x-full': !$store.app.sidebarOpen,
        'translate-x-0': $store.app.sidebarOpen
    }">
    <div class="relative h-full px-6 sm:px-4 py-4 overflow-y-auto bg-white/95 dark:bg-gray-800/95 backdrop-blur-lg border-r border-gray-200 dark:border-gray-700">
        <!-- Mobil Üst Bar -->
        <div class="flex items-center justify-between mb-8 sm:hidden">
            <!-- Tema Değiştirme Butonu -->
            <button 
                @click="darkMode = !darkMode" 
                class="w-9 h-9 flex items-center justify-center rounded-lg bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-primary-800/50 transition-all duration-200 group"
            >
                <i class="fa-solid fa-sun text-amber-500 dark:hidden transition-transform duration-300 group-hover:rotate-45"></i>
                <i class="fa-solid fa-moon text-primary-400 hidden dark:inline-block transition-transform duration-300 group-hover:-rotate-12"></i>
            </button>

            <!-- Mobil Kapatma Butonu -->
            <button @click="$store.app.toggleSidebar()" 
                class="w-9 h-9 flex items-center justify-center rounded-lg bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-primary-800/50 transition-all duration-200">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div class="mb-6 p-4">
            <h2 class="text-xl sm:text-2xl font-secondary font-bold text-gray-800 dark:text-white">urlredgrimJS V1</h2>
        </div>
        
        <ul class="space-y-2 font-secondary">
            <li>
                <a href="#" @click.prevent="$store.app.setPage('dashboard')" 
                    class="flex items-center p-3 text-gray-900 dark:text-white rounded-xl transition-colors"
                    :class="$store.app.currentPage === 'dashboard' ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-primary-50 dark:hover:bg-primary-900/50'">
                    <i class="fa-solid fa-gauge-high w-5 h-5 text-primary-600 dark:text-primary-400 transition-colors"></i>
                    <span class="ml-3 text-sm sm:text-base">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="#" @click.prevent="$store.app.setPage('link-add')"
                    class="flex items-center p-3 text-gray-900 dark:text-white rounded-xl transition-colors"
                    :class="$store.app.currentPage === 'link-add' ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-primary-50 dark:hover:bg-primary-900/50'">
                    <i class="fa-solid fa-plus w-5 h-5 text-primary-600 dark:text-primary-400 transition-colors"></i>
                    <span class="ml-3 text-sm sm:text-base">Yeni Link Ekle</span>
                </a>
            </li>
            <li>
                <a href="#" @click.prevent="$store.app.setPage('links')"
                    class="flex items-center p-3 text-gray-900 dark:text-white rounded-xl transition-colors"
                    :class="$store.app.currentPage === 'links' ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-primary-50 dark:hover:bg-primary-900/50'">
                    <i class="fa-solid fa-link w-5 h-5 text-primary-600 dark:text-primary-400 transition-colors"></i>
                    <span class="ml-3 text-sm sm:text-base">Linkler</span>
                </a>
            </li>
            <li>
                <a href="#" @click.prevent="$store.app.setPage('settings')"
                    class="flex items-center p-3 text-gray-900 dark:text-white rounded-xl transition-colors"
                    :class="$store.app.currentPage === 'settings' ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-primary-50 dark:hover:bg-primary-900/50'">
                    <i class="fa-solid fa-gear w-5 h-5 text-primary-600 dark:text-primary-400 transition-colors"></i>
                    <span class="ml-3 text-sm sm:text-base">Ayarlar</span>
                </a>
            </li>
        </ul>

        <div class="absolute bottom-0 left-0 right-0 p-4">
            <button onclick="handleLogout()" class="group flex items-center justify-center w-full px-6 py-3 text-sm font-medium text-white bg-gradient-to-br from-primary-500 via-primary-600 to-primary-500 hover:from-primary-600 hover:via-primary-700 hover:to-primary-600 dark:from-primary-600 dark:via-primary-700 dark:to-primary-600 dark:hover:from-primary-700 dark:hover:via-primary-800 dark:hover:to-primary-700 rounded-xl shadow-lg shadow-primary-500/20 dark:shadow-primary-700/20 transform hover:-translate-y-0.5 transition-all duration-200 backdrop-blur-lg">
                <i class="fa-solid fa-right-from-bracket text-white/90 group-hover:translate-x-1 transition-transform duration-200"></i>
                <span class="ml-2.5 text-sm sm:text-base">Çıkış Yap</span>
            </button>
        </div>
    </div>
</aside>

<!-- Sidebar Overlay -->
<div 
    @click="$store.app.sidebarOpen = false"
    class="fixed inset-0 z-30 bg-gray-900/50 backdrop-blur-sm transition-opacity duration-300 sm:hidden"
    :class="$store.app.sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'">
</div> 