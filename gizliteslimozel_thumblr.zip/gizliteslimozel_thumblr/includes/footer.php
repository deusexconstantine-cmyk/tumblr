    </main>
    <footer class="bg-white/80 dark:bg-gray-800/80 backdrop-blur-md shadow-lg mt-auto">
        <div class="max-w-7xl mx-auto px-6 py-5">
            <div class="flex items-center justify-center">
                <p class="text-sm font-secondary text-gray-500 dark:text-gray-400">
                    <span class="font-medium text-gray-700 dark:text-gray-300">urlredgrimJS Oto Yönlendirme V1</span> — © <?php echo date('Y'); ?>
                </p>
            </div>
        </div>
    </footer>
</body>
</html> 