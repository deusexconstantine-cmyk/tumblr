<?php
class Router {
    private static $instance = null;
    private $routes = [];
    private $currentRoute = null;

    private function __construct() {
        // Varsayılan rotaları tanımla
        $this->routes = [
            '/' => [
                'title' => 'Dashboard',
                'description' => 'urlredgrimJs Oto Yönlendirme Sistemi',
                'slug' => 'home',
                'file' => 'index.php',
                'view' => 'dashboard',
                'auth' => true
            ],
            '/login' => [
                'title' => 'Giriş Yap',
                'description' => 'Hesabınıza giriş yapın',
                'slug' => 'login',
                'file' => 'index.php',
                'view' => 'login',
                'auth' => false
            ],
            '/dashboard' => [
                'title' => 'Dashboard',
                'description' => 'Yönetim Paneli',
                'slug' => 'dashboard',
                'file' => 'index.php',
                'view' => 'dashboard',
                'auth' => true
            ],
            '/link-add' => [
                'title' => 'Link Ekle',
                'description' => 'Yeni Link Ekle',
                'slug' => 'link-add',
                'file' => 'index.php',
                'view' => 'link-add',
                'auth' => true
            ],
            '/links' => [
                'title' => 'Linkler',
                'description' => 'Tüm Linkler',
                'slug' => 'links',
                'file' => 'index.php',
                'view' => 'links',
                'auth' => true
            ],
            '/link-edit' => [
                'title' => 'Link Düzenle',
                'description' => 'Link Düzenle',
                'slug' => 'link-edit',
                'file' => 'index.php',
                'view' => 'link-edit',
                'auth' => true
            ],
            '404' => [
                'title' => 'Sayfa Bulunamadı',
                'description' => 'Aradığınız sayfa bulunamadı',
                'slug' => '404',
                'file' => 'index.php',
                'view' => '404',
                'auth' => false
            ],
            '/settings' => [
                'title' => 'Ayarlar',
                'description' => 'Hesap Ayarları',
                'slug' => 'settings',
                'file' => 'index.php',
                'view' => 'settings',
                'auth' => true
            ]
        ];
    }

    // Singleton pattern
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Mevcut URL'i al
    private function getCurrentUrl() {
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        return $path === '' ? '/' : $path;
    }

    // Rota kontrolü
    public function route() {
        $url = $this->getCurrentUrl();
        $route = $this->routes[$url] ?? $this->routes['404'];
        $this->currentRoute = $route;

        // Oturum açmış kullanıcı login sayfasına erişmeye çalışırsa dashboard'a yönlendir
        if ($url === '/login' && isset($_SESSION['admin_id'])) {
            header('Location: /dashboard');
            exit;
        }

        // Yetki kontrolü
        if ($route['auth'] && !isset($_SESSION['admin_id'])) {
            header('Location: /login');
            exit;
        }

        return $route;
    }

    // Meta bilgilerini al
    public function getTitle() {
        return $this->currentRoute['title'] ?? 'urlredgrimJs';
    }

    public function getDescription() {
        return $this->currentRoute['description'] ?? '';
    }

    public function getSlug() {
        return $this->currentRoute['slug'] ?? '';
    }

    public function getFile() {
        return $this->currentRoute['file'] ?? '404.php';
    }

    public function getView() {
        return $this->currentRoute['view'] ?? '404';
    }

    // Yeni rota ekle
    public function addRoute($path, $config) {
        $this->routes[$path] = $config;
    }
}

// Router'ı başlat
$router = Router::getInstance();
$currentRoute = $router->route();

// Örnek kullanım:
// $title = $router->getTitle();
// $description = $router->getDescription();
// $slug = $router->getSlug();
?> 